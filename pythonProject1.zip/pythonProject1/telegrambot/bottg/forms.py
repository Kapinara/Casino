from django import forms
from .models import TelegramUser


class BroadcastForm(forms.Form):
    message = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'placeholder': 'Введите сообщение для рассылки',
            'rows': 4
        }),
        label='Сообщение рассылки'
    )

    secret_code = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Введите секретный код'
        }),
        label='Секретный код',
        max_length=100
    )