from django.shortcuts import render, redirect
from django.contrib import messages
from .models import TelegramUser
from .forms import BroadcastForm
from .telegram import broadcast_message


def user_list(request):
    users = TelegramUser.objects.all().order_by('-created_at')

    if request.method == 'POST':
        form = BroadcastForm(request.POST)
        if form.is_valid():
            message = form.cleaned_data['message']
            secret_code = form.cleaned_data['secret_code']

            success, result = broadcast_message(users, message, secret_code)

            if success:
                messages.success(request, f'Рассылка завершена! Отправлено {len(users)} сообщений.')
            else:
                messages.error(request, result)

            return redirect('user_list')
    else:
        form = BroadcastForm()

    return render(request, 'my_form.html', {
        'users': users,
        'form': form
    })