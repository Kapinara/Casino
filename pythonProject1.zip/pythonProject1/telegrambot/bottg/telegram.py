import requests
from django.conf import settings


def send_telegram_message(chat_id, message):
    bot_token = settings.TELEGRAM_BOT_TOKEN
    url = f"https://api.telegram.org/bot8367461026:AAGi7n3MKf-60Z2KfKk0jhtCPpe2DuIOlnU/sendMessage"

    data = {
        'chat_id': chat_id,
        'text': message,
        'parse_mode': 'HTML'
    }

    try:
        response = requests.post(url, data=data)
        response.raise_for_status()
        return True, "Сообщение отправлено"
    except Exception as e:
        return False, f"Ошибка: {str(e)}"


def broadcast_message(users, message, secret_code):
    if secret_code != settings.SECRET_CODE:
        return False, "Неверный секретный код"

    results = []
    for user in users:
        success, result_msg = send_telegram_message(user.telegram_id, message)
        results.append({
            'user': user.full_name,
            'success': success,
            'message': result_msg
        })

    return True, results