import requests
from django.conf import settings


def get_updates():
    token = settings.TELEGRAM_BOT_TOKEN
    url = f"https://api.telegram.org/bot{8367461026:AAGi7n3MKf-60Z2KfKk0jhtCPpe2DuIOlnU}/getUpdates"

    response = requests.get(url)
    data = response.json()

    print("Последние сообщения:")
    for update in data.get('result', []):
        if 'message' in update:
            user = update['message']['from']
            print(f"ID: {user['id']}, Имя: {user.get('first_name', '')}")


if __name__ == "__main__":
    import django
    import os

    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'settings')
    django.setup()
    get_updates()