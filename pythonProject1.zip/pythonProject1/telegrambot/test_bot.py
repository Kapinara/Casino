import requests


TOKEN = "8367461026:AAGi7n3MKf-60Z2KfKk0jhtCPpe2DuIOlnU"


def test_bot():
    url = f"https://api.telegram.org/bot{8367461026:AAGi7n3MKf-60Z2KfKk0jhtCPpe2DuIOlnU}/getMe"
    response = requests.get(url)

    if response.status_code == 200:
        print("Бот активен!")
        bot_data = response.json()
        print(f"Имя бота: {bot_data['result']['first_name']}")
        print(f"Username: @{bot_data['result']['username']}")
    else:
        print("Ошибка! Проверьте токен бота")
        print(f"Код ошибки: {response.status_code}")
        print(f"Ответ: {response.text}")


if __name__ == "__main__":
    test_bot()